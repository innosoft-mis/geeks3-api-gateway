#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import sqlalchemy as sa
from urllib.parse import quote

## 1. Extract from 202.44.12.115

conn_str = f"mysql+pymysql://testuser:{quote('P@ssw0rd')}@202.44.12.115:3306/de_inter"
engine = sa.create_engine(conn_str)
conn = engine.connect()
chospital = pd.read_sql("chospital", conn)
conn.close()

## 2. Load to Localhost

conn_str = f"mysql+pymysql://user:user@hospital-db:3306/hospital"
engine = sa.create_engine(conn_str)
conn = engine.connect()
chospital.to_sql("hospital", conn, index=None, if_exists="replace")
conn.close()
