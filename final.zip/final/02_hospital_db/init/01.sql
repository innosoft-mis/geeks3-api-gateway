CREATE DATABASE IF NOT EXISTS `hospital`;
GRANT ALL ON `hospital`.* TO 'user'@'%’;
